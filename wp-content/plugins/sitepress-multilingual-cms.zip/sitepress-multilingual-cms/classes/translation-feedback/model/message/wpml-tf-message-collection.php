<?php

/**
 * Class WPML_TF_Message_Collection
 *
 * @author OnTheGoSystems
 */
class WPML_TF_Message_Collection extends WPML_TF_Collection {

}